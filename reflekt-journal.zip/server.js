require('dotenv').config();
const express = require('express');
const Database = require('better-sqlite3');
const path = require('path');
const app = express();

const PORT = process.env.PORT || 3000;
const CLAUDE_API_KEY = process.env.CLAUDE_API_KEY || '';

// --- Database Setup ---
const dbPath = process.env.DB_PATH || path.join(__dirname, 'data', 'journal.db');
const fs = require('fs');
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS entries (
    date TEXT PRIMARY KEY,
    body TEXT NOT NULL DEFAULT '',
    tags TEXT NOT NULL DEFAULT '[]',
    created_at INTEGER NOT NULL DEFAULT (unixepoch()),
    updated_at INTEGER NOT NULL DEFAULT (unixepoch())
  );

  CREATE TABLE IF NOT EXISTS excerpts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    topic TEXT NOT NULL DEFAULT 'Uncategorized',
    source_date TEXT,
    created_at INTEGER NOT NULL DEFAULT (unixepoch())
  );

  CREATE TABLE IF NOT EXISTS summaries (
    key TEXT PRIMARY KEY,
    text TEXT NOT NULL,
    created_at INTEGER NOT NULL DEFAULT (unixepoch())
  );
`);

// --- Middleware ---
app.use(express.json({ limit: '5mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// --- API Routes ---

// ENTRIES
app.get('/api/entries', (req, res) => {
  const rows = db.prepare('SELECT * FROM entries ORDER BY date DESC').all();
  const entries = {};
  rows.forEach(r => {
    entries[r.date] = { body: r.body, tags: JSON.parse(r.tags), date: r.date, updatedAt: r.updated_at };
  });
  res.json(entries);
});

app.get('/api/entries/:date', (req, res) => {
  const row = db.prepare('SELECT * FROM entries WHERE date = ?').get(req.params.date);
  if (!row) return res.json(null);
  res.json({ body: row.body, tags: JSON.parse(row.tags), date: row.date, updatedAt: row.updated_at });
});

app.put('/api/entries/:date', (req, res) => {
  const { body, tags } = req.body;
  const date = req.params.date;
  const now = Math.floor(Date.now() / 1000);
  db.prepare(`
    INSERT INTO entries (date, body, tags, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(date) DO UPDATE SET body = excluded.body, tags = excluded.tags, updated_at = excluded.updated_at
  `).run(date, body || '', JSON.stringify(tags || []), now, now);
  res.json({ success: true });
});

app.delete('/api/entries/:date', (req, res) => {
  db.prepare('DELETE FROM entries WHERE date = ?').run(req.params.date);
  res.json({ success: true });
});

// EXCERPTS
app.get('/api/excerpts', (req, res) => {
  const rows = db.prepare('SELECT * FROM excerpts ORDER BY created_at DESC').all();
  res.json(rows);
});

app.post('/api/excerpts', (req, res) => {
  const { text, topic, source_date } = req.body;
  const result = db.prepare('INSERT INTO excerpts (text, topic, source_date) VALUES (?, ?, ?)').run(text, topic || 'Uncategorized', source_date || '');
  res.json({ id: result.lastInsertRowid, success: true });
});

app.delete('/api/excerpts/:id', (req, res) => {
  db.prepare('DELETE FROM excerpts WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// SUMMARIES
app.get('/api/summaries', (req, res) => {
  const rows = db.prepare('SELECT * FROM summaries ORDER BY created_at DESC').all();
  const summaries = {};
  rows.forEach(r => { summaries[r.key] = { text: r.text, createdAt: r.created_at }; });
  res.json(summaries);
});

app.put('/api/summaries/:key', (req, res) => {
  const { text } = req.body;
  const now = Math.floor(Date.now() / 1000);
  db.prepare(`
    INSERT INTO summaries (key, text, created_at) VALUES (?, ?, ?)
    ON CONFLICT(key) DO UPDATE SET text = excluded.text, created_at = excluded.created_at
  `).run(req.params.key, text, now);
  res.json({ success: true });
});

// STATS
app.get('/api/stats', (req, res) => {
  const totalEntries = db.prepare('SELECT COUNT(*) as count FROM entries').get().count;
  const rows = db.prepare('SELECT body FROM entries').all();
  let totalWords = 0;
  rows.forEach(r => {
    const text = r.body.replace(/<[^>]*>/g, '');
    totalWords += text.split(/\s+/).filter(w => w).length;
  });

  // Calculate streak
  let streak = 0;
  const today = new Date();
  while (true) {
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, '0');
    const d = String(today.getDate()).padStart(2, '0');
    const key = `${y}-${m}-${d}`;
    const exists = db.prepare('SELECT 1 FROM entries WHERE date = ?').get(key);
    if (exists) { streak++; today.setDate(today.getDate() - 1); }
    else break;
  }

  const avgWords = totalEntries ? Math.round(totalWords / totalEntries) : 0;
  res.json({ totalEntries, totalWords, streak, avgWords });
});

// ALL TAGS
app.get('/api/tags', (req, res) => {
  const rows = db.prepare('SELECT tags FROM entries').all();
  const tagSet = new Set();
  rows.forEach(r => {
    JSON.parse(r.tags).forEach(t => tagSet.add(t));
  });
  res.json([...tagSet].sort());
});

// CLAUDE API PROXY
app.post('/api/claude', async (req, res) => {
  if (!CLAUDE_API_KEY) {
    return res.status(400).json({ error: 'Claude API key not configured on server.' });
  }

  try {
    const { prompt, system } = req.body;
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': CLAUDE_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-5-20250514',
        max_tokens: 2000,
        system: system || 'You are a thoughtful journal assistant. Be warm, insightful, and concise.',
        messages: [{ role: 'user', content: prompt }]
      })
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      return res.status(response.status).json({ error: err.error?.message || `API error: ${response.status}` });
    }

    const data = await response.json();
    res.json({ text: data.content[0].text });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// EXPORT
app.get('/api/export', (req, res) => {
  const entries = {};
  db.prepare('SELECT * FROM entries').all().forEach(r => {
    entries[r.date] = { body: r.body, tags: JSON.parse(r.tags), date: r.date };
  });
  const excerpts = db.prepare('SELECT * FROM excerpts ORDER BY created_at DESC').all();
  const summaries = {};
  db.prepare('SELECT * FROM summaries').all().forEach(r => {
    summaries[r.key] = { text: r.text };
  });
  res.json({ entries, excerpts, summaries, exportedAt: new Date().toISOString() });
});

// IMPORT
app.post('/api/import', (req, res) => {
  const { entries, excerpts, summaries } = req.body;
  const now = Math.floor(Date.now() / 1000);

  const insertEntry = db.prepare(`
    INSERT INTO entries (date, body, tags, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(date) DO UPDATE SET body = excluded.body, tags = excluded.tags, updated_at = excluded.updated_at
  `);

  const insertExcerpt = db.prepare('INSERT INTO excerpts (text, topic, source_date, created_at) VALUES (?, ?, ?, ?)');
  const insertSummary = db.prepare(`
    INSERT INTO summaries (key, text, created_at) VALUES (?, ?, ?)
    ON CONFLICT(key) DO UPDATE SET text = excluded.text
  `);

  const tx = db.transaction(() => {
    if (entries) {
      Object.keys(entries).forEach(date => {
        const e = entries[date];
        insertEntry.run(date, e.body || '', JSON.stringify(e.tags || []), now, now);
      });
    }
    if (excerpts) {
      excerpts.forEach(e => {
        insertExcerpt.run(e.text, e.topic || 'Uncategorized', e.source_date || '', now);
      });
    }
    if (summaries) {
      Object.keys(summaries).forEach(key => {
        insertSummary.run(key, summaries[key].text, now);
      });
    }
  });

  tx();
  res.json({ success: true });
});

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`✨ Reflekt Journal running at http://localhost:${PORT}`);
});
