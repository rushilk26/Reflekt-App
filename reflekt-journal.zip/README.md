# Reflekt — Daily Journal

A private, AI-powered daily journaling app with smart summaries, excerpts, and semantic search.

## Features

- **Daily Journaling** — Rich text editor with tags
- **Calendar View** — Browse past entries by date
- **AI Summaries** — Weekly/monthly summaries powered by Claude
- **Excerpts** — Highlight & save text, organized by topic
- **Smart Search** — Full-text + AI semantic search
- **Export/Import** — Full data backup as JSON

## Deploy to Railway

### Step 1: Push to GitHub

```bash
cd journal-app
git init
git add .
git commit -m "Initial commit - Reflekt Journal"
```

Create a new repo on GitHub, then:

```bash
git remote add origin https://github.com/YOUR_USERNAME/reflekt-journal.git
git branch -M main
git push -u origin main
```

### Step 2: Deploy on Railway

1. Go to [railway.app](https://railway.app) and sign in with GitHub
2. Click **"New Project"** → **"Deploy from GitHub Repo"**
3. Select your `reflekt-journal` repo
4. Railway will auto-detect the Dockerfile and start building

### Step 3: Add Environment Variables

In Railway dashboard → your project → **Variables** tab, add:

```
CLAUDE_API_KEY=sk-ant-api03-your-key-here
PORT=3000
DB_PATH=/app/data/journal.db
```

### Step 4: Add Persistent Volume

In Railway dashboard → your service → **Settings** → **Volumes**:
- Click **"Add Volume"**
- Mount path: `/app/data`
- This ensures your SQLite database persists across deployments

### Step 5: Generate Domain

In Railway dashboard → your service → **Settings** → **Networking**:
- Click **"Generate Domain"**
- You'll get a URL like `reflekt-journal-production.up.railway.app`

That's it! Open the URL from any device to access your journal.

## Local Development

```bash
npm install
cp .env.example .env  # Add your Claude API key
npm start
# Open http://localhost:3000
```

## Tech Stack

- **Backend:** Node.js + Express
- **Database:** SQLite (via better-sqlite3)
- **AI:** Claude API (Anthropic)
- **Frontend:** Vanilla HTML/CSS/JS
- **Hosting:** Railway

## Data Privacy

Your journal data is stored in a SQLite database on Railway's persistent volume. Only you can access it through the app URL. The Claude API key is stored server-side as an environment variable — never exposed to the browser.
